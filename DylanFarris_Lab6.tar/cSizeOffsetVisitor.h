#pragma once
#include "cVisitor.h"
#include "cAstNode.h"
#include "cDeclNode.h"
#include "cVarDeclNode.h"
#include "cArrayDeclNode.h"
#include "cFuncDeclNode.h"
#include "cBlockNode.h"
#include "cVarExprNode.h"
#include "cArrayExprNode.h"

class cSizeOffsetVisitor : public cVisitor
{
protected:
    int currentOffset = 0;  // tracks offset in the current scope

public:
    cSizeOffsetVisitor() {}

    // Visitors for declarations
    virtual void Visit(cVarDeclNode *node) override;
    virtual void Visit(cArrayDeclNode *node) override;
    virtual void Visit(cFuncDeclNode *node) override;

    // Visitor for blocks (inner scopes)
    virtual void Visit(cBlockNode *node) override;

    // Visitors for variable and array expressions
    virtual void Visit(cVarExprNode *node) override;
    virtual void Visit(cArrayExprNode *node) override;

    // Default visitor: visit children
    virtual void Visit(cAstNode *node) override { node->VisitChildren(this); }
};
