#pragma once
#include "cVisitor.h"
#include "cAstNode.h"
#include "cDeclNode.h"
#include "cAssignNode.h"
#include "cVarExprNode.h"
#include "cArrayExprNode.h"
#include "cFuncCallNode.h"
#include "cUnaryExprNode.h"
#include "cBinaryExprNode.h"
#include "langparse.h"  // for SemanticParseError

class cSemanticVisitor : public cVisitor
{
public:
    // Constructor
    cSemanticVisitor() {}

    // Visit methods for nodes that require semantic checking
    virtual void Visit(cAssignNode *node) override;
    virtual void Visit(cVarExprNode *node) override;
    virtual void Visit(cArrayExprNode *node) override;
    virtual void Visit(cFuncCallNode *node) override;
    virtual void Visit(cUnaryExprNode *node) override;
    virtual void Visit(cBinaryExprNode *node) override;

    // Optional: other visit methods can be empty
    virtual void Visit(cAstNode *node) override { node->VisitChildren(this); }
};
