#pragma once

#include "cDeclNode.h"
#include "cSymbol.h"
#include "cVisitor.h"

class cVarDeclNode : public cDeclNode
{
public:
    cVarDeclNode(cSymbol *type, cSymbol *name) : cDeclNode()
    {
        AddChild(type);
        AddChild(name);
    }
    cDeclNode* cVarDeclNode::GetDecl() 
    { 
        return this; // The variable declaration IS its own declaration
    }
    cVarDeclNode::cVarDeclNode(cSymbol* sym, cDeclNode* type)
    {   
        m_symbol = sym;
        m_type = type;

        // Check if symbol already exists in this scope
        if (g_SymbolTable->FindLocal(sym->GetName()))
            SemanticParseError("Symbol " + sym->GetName() + " already defined in current scope");
        else
            g_SymbolTable->AddSymbol(sym); // only add if no duplicate
    }
    virtual std::string NodeType() { return "var_decl"; }

    virtual void Visit(cVisitor *visitor) { visitor->Visit(this); }
};
