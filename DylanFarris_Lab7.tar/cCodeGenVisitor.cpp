#include "cCodeGenVisitor.h"

//---------------------- Assignment ----------------------
void cCodeGenVisitor::Visit(cAssignNode *node)
{
    // Generate code for RHS first (push result onto stack)
    node->GetRhs()->Visit(this);

    // LHS could be a variable or array reference
    cVarExprNode *lhsVar = dynamic_cast<cVarExprNode*>(node->GetLhs());
    cArrayExprNode *lhsArr = dynamic_cast<cArrayExprNode*>(node->GetLhs());

    if (lhsVar)
    {
        int offset = lhsVar->GetDecl()->GetOffset();
        EmitStore(offset); // store RHS into variable
    }
    else if (lhsArr)
    {
        // Array reference: address computed in array expr
        lhsArr->Visit(this);   // push array value
        EmitStoreAddr();       // store into memory at address on stack
    }
}

//---------------------- Variable ----------------------
void cCodeGenVisitor::Visit(cVarExprNode *node)
{
    int offset = node->GetDecl()->GetOffset();
    EmitLoad(offset);   // push value of variable onto stack
}

//---------------------- Array Reference ----------------------
void cCodeGenVisitor::Visit(cArrayExprNode *node)
{
    // Compute index first
    node->GetIndex()->Visit(this);         // push index

    // Multiply by element size
    EmitPushConst(node->GetElemSize());
    EmitMul();                             // index * elemSize

    // Add base address
    int baseOffset = node->GetArray()->GetDecl()->GetOffset();
    EmitPushConst(baseOffset);
    EmitAdd();                             // absolute address

    // Load value from computed address
    EmitLoadAddr();                        // helper in emit.cpp
}

//---------------------- Binary Expression ----------------------
void cCodeGenVisitor::Visit(cBinaryExprNode *node)
{
    node->GetLeft()->Visit(this);   // push left
    node->GetRight()->Visit(this);  // push right

    switch(node->GetOp())
    {
        case '+': EmitAdd(); break;
        case '-': EmitSub(); break;
        case '*': EmitMul(); break;
        case '/': EmitDiv(); break;
        case '>': EmitGt(); break;
        case '<': EmitLt(); break;
        case '=': EmitEq(); break;
        case '!': EmitNe(); break;
        case '&': EmitAnd(); break;
        case '|': EmitOr(); break;
        default: break;
    }
}

//---------------------- Unary Expression ----------------------
void cCodeGenVisitor::Visit(cUnaryExprNode *node)
{
    node->GetExpr()->Visit(this);

    switch(node->GetOp())
    {
        case '-': EmitNeg(); break;
        case '!': EmitNot(); break;
    }
}

//---------------------- Function Call ----------------------
void cCodeGenVisitor::Visit(cFuncCallNode *node)
{
    // Push arguments onto stack
    for (auto arg : node->GetArgs())
        arg->Visit(this);

    // Call function
    EmitCall(node->GetDecl()->GetName());

    // Function result left on stack
}

//---------------------- Function Declaration ----------------------
void cCodeGenVisitor::Visit(cFuncDeclNode *node)
{
    EmitLabel(node->GetName());       // label for function
    EmitEnter(node->GetSize());       // allocate space for locals

    node->GetBody()->Visit(this);     // generate code for body

    EmitLeave();                      // cleanup stack frame
    EmitRet();                        // return to caller
}

//---------------------- Block ----------------------
void cCodeGenVisitor::Visit(cBlockNode *node)
{
    node->VisitChildren(this);        // just traverse contained statements
}
