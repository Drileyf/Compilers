#pragma once
//**************************************
// cDeclNode
//
// Defines base class for all declarations.
// Future labs will add features to this class.
//
// Author: Phil Howard 
// phil.howard@oit.edu
//

#include "cAstNode.h"

class cDeclNode : public cAstNode
{
    protected:
        int m_size = 0;
        int m_offset = 0;

    public:
        int GetSize() { return m_size; }
        void SetSize(int size) { m_size = size; }

        int GetOffset() { return m_offset; }
        void SetOffset(int offset) { m_offset = offset; }

        // override AttributesToString
        virtual std::string AttributesToString() override
        {
            if (m_size == 0 && m_offset == 0) return "";
            return " size=" + std::to_string(m_size) + " offset=" + std::to_string(m_offset);
        }

        cDeclNode() : cAstNode() {}
        virtual bool IsArray()  { return false; }
        virtual bool IsStruct() { return false; }
        virtual bool IsType()   { return false; }
        virtual bool IsFunc()   { return false; }
        virtual bool IsVar()    { return false; }
        virtual bool IsFloat()  { return false; }
        virtual bool IsInt()    { return false; }
        virtual bool IsChar()   { return false; }
        virtual int  GetSize()  { return 0; }
        virtual cDeclNode *GetType() = 0;
};
