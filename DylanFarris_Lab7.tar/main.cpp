#include <iostream>
#include "langparse.h"        // Bison parser
#include "cAstNode.h"         // AST root
#include "cSemanticVisitor.h" // Lab 5b semantic visitor
#include "cSizeOffsetVisitor.h" // Lab 6 visitor
#include "cCodeGenVisitor.h"  // Lab 7 visitor

extern cAstNode *g_root;      // the root of the AST from parser

int main(int argc, char **argv)
{
    // 1. Parse the source file
    yyparse();                  // builds AST in g_root
    if (!g_root)
    {
        std::cerr << "Parsing failed.\n";
        return 1;
    }

    // 2. Run semantic checking (Lab 5b)
#ifdef LAB5B
    cSemanticVisitor semVisitor;
    semVisitor.VisitAllNodes(g_root);
#endif

    // 3. Compute sizes/offsets (Lab 6)
#ifdef LAB6
    cSizeOffsetVisitor sizeVisitor;
    sizeVisitor.VisitAllNodes(g_root);
#endif

    // 4. Generate StackL code (Lab 7)
#ifdef LAB7
    cCodeGenVisitor codegen;
    codegen.VisitAllNodes(g_root);   // <-- Step 12 code goes here
#endif

    return 0;
}
