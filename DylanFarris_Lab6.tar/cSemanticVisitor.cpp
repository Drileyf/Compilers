#include "cSemanticVisitor.h"

//---------------------- Assignment ----------------------
void cSemanticVisitor::Visit(cAssignNode *node)
{
    cDeclNode *lhsType = node->GetLhs()->GetType();
    cDeclNode *rhsType = node->GetRhs()->GetType();

    if (!lhsType->IsCompatibleWith(rhsType))
    {
        SemanticParseError("Cannot assign " + rhsType->GetName() + " to " + lhsType->GetName());
    }

    // Visit children
    node->GetLhs()->Visit(this);
    node->GetRhs()->Visit(this);
}

//---------------------- Variable Expression ----------------------
void cSemanticVisitor::Visit(cVarExprNode *node)
{
    cDeclNode *decl = node->GetDecl();
    if (!decl)
    {
        SemanticParseError("Symbol not defined");
        return;
    }

    if (decl->IsFunc())
    {
        SemanticParseError("Symbol " + decl->GetName() + " is a function, not a variable");
    }
}

//---------------------- Array Reference ----------------------
void cSemanticVisitor::Visit(cArrayExprNode *node)
{
    cDeclNode *parentType = node->GetArray()->GetType();
    if (!parentType->IsArray())
    {
        SemanticParseError(parentType->GetName() + " is not an array");
    }

    if (!node->GetIndex()->GetType()->IsInt())
    {
        SemanticParseError("Index of " + parentType->GetName() + " is not an int");
    }

    node->GetArray()->Visit(this);
    node->GetIndex()->Visit(this);
}

//---------------------- Function Call ----------------------
void cSemanticVisitor::Visit(cFuncCallNode *node)
{
    cFuncDeclNode *funcDecl = dynamic_cast<cFuncDeclNode*>(node->GetDecl());
    if (!funcDecl)
    {
        SemanticParseError("Function not defined");
        return;
    }

    if (!funcDecl->IsDefined())
    {
        SemanticParseError("Function " + funcDecl->GetName() + " not fully defined");
    }

    // Argument count
    if (node->GetArgs().size() != funcDecl->GetParams().size())
    {
        SemanticParseError(funcDecl->GetName() + " called with wrong number of arguments");
    }

    // Argument type check
    for (size_t i = 0; i < node->GetArgs().size() && i < funcDecl->GetParams().size(); i++)
    {
        if (!funcDecl->GetParams()[i]->GetType()->IsCompatibleWith(node->GetArgs()[i]->GetType()))
        {
            SemanticParseError("Function " + funcDecl->GetName() + " called with incompatible argument");
        }
    }

    // Visit all arguments
    for (auto arg : node->GetArgs())
        arg->Visit(this);
}

//---------------------- Unary Expression ----------------------
void cSemanticVisitor::Visit(cUnaryExprNode *node)
{
    cDeclNode *operandType = node->GetExpr()->GetType();
    node->SetType(operandType);
    node->GetExpr()->Visit(this);
}

//---------------------- Binary Expression ----------------------
void cSemanticVisitor::Visit(cBinaryExprNode *node)
{
    cDeclNode *leftType = node->GetLeft()->GetType();
    cDeclNode *rightType = node->GetRight()->GetType();

    if (node->IsRelationalOrLogical())
    {
        node->SetType(g_SymbolTable->Find("int")->GetDecl()); // relational/logical operators return int
    }
    else
    {
        // Choose largest type (promotion)
        if (leftType->IsFloat() || rightType->IsFloat())
            node->SetType(g_SymbolTable->Find("float")->GetDecl());
        else
            node->SetType(g_SymbolTable->Find("int")->GetDecl());
    }

    node->GetLeft()->Visit(this);
    node->GetRight()->Visit(this);
}
