#include "cSizeOffsetVisitor.h"

//---------------------- Variable Declaration ----------------------
void cSizeOffsetVisitor::Visit(cVarDeclNode *node)
{
    cDeclNode *type = node->GetType();
    int size = type->GetSize();

    // 4-byte alignment
    if (size > 1 && currentOffset % 4 != 0)
        currentOffset += (4 - (currentOffset % 4));

    node->SetOffset(currentOffset);
    node->SetSize(size);

    currentOffset += size;

    node->VisitChildren(this);  // visit initializer if any
}

//---------------------- Array Declaration ----------------------
void cSizeOffsetVisitor::Visit(cArrayDeclNode *node)
{
    cDeclNode *elemType = node->GetType();   // element type
    int elemSize = elemType->GetSize();
    int arraySize = elemSize * node->GetNumElements();

    // 4-byte alignment
    if (arraySize > 1 && currentOffset % 4 != 0)
        currentOffset += (4 - (currentOffset % 4));

    node->SetOffset(currentOffset);
    node->SetSize(arraySize);

    currentOffset += arraySize;

    node->VisitChildren(this);  // visit initializer if any
}

//---------------------- Function Declaration ----------------------
void cSizeOffsetVisitor::Visit(cFuncDeclNode *node)
{
    int savedOffset = currentOffset;  // save outer scope offset
    currentOffset = 0;                // start offset for function scope

    // Compute size for parameters and local variables
    node->VisitChildren(this);

    node->SetSize(currentOffset);     // total size of function locals
    currentOffset = savedOffset;      // restore outer scope offset
}

//---------------------- Block / Inner Scope ----------------------
void cSizeOffsetVisitor::Visit(cBlockNode *node)
{
    int savedOffset = currentOffset;
    currentOffset = 0;  // start offset for block

    node->VisitChildren(this);

    node->SetSize(currentOffset);  // total size of block
    currentOffset = savedOffset;   // restore outer scope offset
}

//---------------------- Variable Expression ----------------------
void cSizeOffsetVisitor::Visit(cVarExprNode *node)
{
    cDeclNode *decl = node->GetDecl();
    if (decl)
    {
        node->SetOffset(decl->GetOffset());
        node->SetSize(decl->GetSize());
    }
}

//---------------------- Array Reference Expression ----------------------
void cSizeOffsetVisitor::Visit(cArrayExprNode *node)
{
    cDeclNode *decl = node->GetArray()->GetDecl();
    if (decl)
    {
        node->SetOffset(decl->GetOffset());
        node->SetSize(decl->GetSize());  // size of array
    }

    node->GetArray()->Visit(this);
    node->GetIndex()->Visit(this);
}
