#pragma once
#include "cVisitor.h"
#include "cAstNode.h"
#include "cDeclNode.h"
#include "cExprNode.h"
#include "cAssignNode.h"
#include "cVarExprNode.h"
#include "cArrayExprNode.h"
#include "cBinaryExprNode.h"
#include "cUnaryExprNode.h"
#include "cFuncCallNode.h"
#include "cFuncDeclNode.h"
#include "cBlockNode.h"
#include "emit.h"

class cCodeGenVisitor : public cVisitor
{
public:
    cCodeGenVisitor() {}

    // Core AST nodes
    virtual void Visit(cAssignNode *node) override;
    virtual void Visit(cVarExprNode *node) override;
    virtual void Visit(cArrayExprNode *node) override;
    virtual void Visit(cBinaryExprNode *node) override;
    virtual void Visit(cUnaryExprNode *node) override;
    virtual void Visit(cFuncCallNode *node) override;
    virtual void Visit(cFuncDeclNode *node) override;
    virtual void Visit(cBlockNode *node) override;

    // Default: traverse children
    virtual void Visit(cAstNode *node) override { node->VisitChildren(this); }
};
